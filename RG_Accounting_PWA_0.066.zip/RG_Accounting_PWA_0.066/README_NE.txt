RG Accounting PWA V0.066 — स्थापना निर्देशन

महत्त्वपूर्ण:
- RG_Accounting_0.066.html एकल HTML फाइल हो। यसलाई Chrome मा खोल्नुहोस् र ⋮ > Add to Home screen (वा Install app उपलब्ध भए Install app) छान्नुहोस्। केही Android/Chrome संस्करणमा स्थानीय file को shortcut Browser मै खुल्न सक्छ।
- पूर्ण App-जस्तो standalone mode, manifest र offline service worker का लागि ZIP भित्रका सबै फाइललाई HTTPS भएको वेबसाइटमा एउटै folder मा राख्नुपर्छ। त्यसपछि Chrome बाट त्यो HTTPS URL खोल्नुहोस् र ⋮ > Install app / Add to Home screen छान्नुहोस्।
- Browser को tab बन्द हुन नदिने काम वेबसाइटले गर्न सक्दैन। Home Screen app icon बाट खोल्दा छुट्टै standalone window मा चल्न सक्छ।
- App को accounting data browser को local storage मा रहन्छ; backup नियमित Download गर्नुहोस्।
